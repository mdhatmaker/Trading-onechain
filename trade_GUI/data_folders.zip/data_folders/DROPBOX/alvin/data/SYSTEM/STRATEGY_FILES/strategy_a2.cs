uint iid;

// Submit some orders...
cout("Submitting orders...");

iid = 111;
m_te.SubmitOrder(m_te.CreateOrder(iid, ZOrderSide.Sell, 251900, 10));
m_te.SubmitOrder(m_te.CreateOrder(iid, ZOrderSide.Buy, 251175, 30));

iid = 444;
m_te.SubmitOrder(m_te.CreateOrder(iid, ZOrderSide.Sell, 170, 7));
m_te.SubmitOrder(m_te.CreateOrder(iid, ZOrderSide.Buy, 070, 7));

//te.SubmitOrder(te.CreateOrder(iid, Side.Sell, 5010, 7));
