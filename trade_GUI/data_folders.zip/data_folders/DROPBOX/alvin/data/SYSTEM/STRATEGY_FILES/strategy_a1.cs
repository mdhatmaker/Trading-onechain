cout("Creating instruments...");
m_te.CreateInstrument(111, "@ESZ17");
m_te.CreateInstrument(666, "QHGZ17");
m_te.CreateInstrument(222, "@VXV17");
m_te.CreateInstrument(333, "@VXX17");
m_te.CreateInstrument(444, "@VXZ17");
m_te.CreateInstrument(555, "M.CU3=LX");

cout("Subscribing to instruments...");
m_te.Subscribe(111);
m_te.Subscribe(666);
m_te.Subscribe(222);
m_te.Subscribe(333);
m_te.Subscribe(444);
m_te.Subscribe(555);
