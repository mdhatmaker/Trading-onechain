﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Tools.G;

namespace ZeroSumAPI
{
    public class StrategyA : TradingEngineCallbacks
    {
        TradingEngine m_te;

        public StrategyA(TradingEngine te)
        {
            m_te = te;
        }

        public void Strategy_CreateInstruments()
        {
            cout("Creating instruments...");
            m_te.CreateInstrument(111, "@ESZ17");
            m_te.CreateInstrument(666, "QHGZ17");
            m_te.CreateInstrument(222, "@VXV17");
            m_te.CreateInstrument(333, "@VXX17");
            m_te.CreateInstrument(444, "@VXZ17");
            m_te.CreateInstrument(555, "M.CU3=LX");

            cout("Subscribing to instruments...");
            m_te.Subscribe(111);
            m_te.Subscribe(666);
            m_te.Subscribe(222);
            m_te.Subscribe(333);
            m_te.Subscribe(444);
            m_te.Subscribe(555);
        }

        public void Strategy_SubmitOrders()
        {
            uint iid;

            // Submit some orders...
            cout("Submitting orders...");

            iid = 111;
            m_te.SubmitOrder(m_te.CreateOrder(iid, ZOrderSide.Sell, 254100, 10));
            m_te.SubmitOrder(m_te.CreateOrder(iid, ZOrderSide.Buy, 253700, 30));

            iid = 444;
            m_te.SubmitOrder(m_te.CreateOrder(iid, ZOrderSide.Sell, 170, 7));
            m_te.SubmitOrder(m_te.CreateOrder(iid, ZOrderSide.Buy, 070, 7));

            //te.SubmitOrder(te.CreateOrder(iid, Side.Sell, 5010, 7));
        }

        public void Strategy_CancelOrders()
        {
            cout("Cancelling orders...");

            m_te.DeleteAllOrders();
        }

        public void Fill(uint iid, uint oid, int price, uint qty)
        {
            cout("FILL iid={0} oid={1} price={2} qty={3}", iid, oid, price, qty);
        }

        public void Trade(uint iid, int price, uint qty)
        {
            cout("TRADE iid={0} price={1} qty={2}", iid, price, qty);
        }

        public void MarketUpdate(uint iid, ZPriceLevels bids, ZPriceLevels asks)
        {
            cout("MARKET_UPDATE iid={0}", iid);
            cout("[asks] " + asks.ToString());
            cout("[bids] " + bids.ToString());
        }

        public void Reject(uint iid, uint oid)
        {
            cout("REJECT iid={0} oid={1}", iid, oid);
        }



    } // end of class
} // end of namespace
